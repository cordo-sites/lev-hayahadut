<?php
// לב היהדות — shop extras, copied into the theme as inc/shop.php by build-wp-theme.cjs.
// Shortcodes (the editor shows them as ordinary blocks): [lev_verse] [lev_chips] [lev_contact].

// the category's verse in a gold frame (verses per top-level category: assets/verses.json)
add_shortcode( 'lev_verse', function () {
	$t = get_queried_object();
	if ( ! ( $t instanceof WP_Term ) ) {
		return '';
	}
	$top    = $t->parent ? get_term( $t->parent, 'product_cat' ) : $t;
	$verses = json_decode( (string) file_get_contents( get_theme_file_path( 'assets/verses.json' ) ), true );
	return isset( $verses[ $top->slug ] ) ? '<div class="verse"><span>' . esc_html( $verses[ $top->slug ] ) . '</span></div>' : '';
} );

// buttons for the groups inside a category (or the 8 categories on the all-products page)
add_shortcode( 'lev_chips', function () {
	$here = get_queried_object();
	$chip = function ( $term, $label, $on ) {
		return '<a class="chip' . ( $on ? ' on' : '' ) . '" href="' . esc_url( get_term_link( $term ) ) . '">' . esc_html( $label ) . ' <small>' . (int) $term->count . '</small></a>';
	};
	$out = '';
	if ( $here instanceof WP_Term ) {
		$top  = $here->parent ? get_term( $here->parent, 'product_cat' ) : $here;
		$kids = get_terms( array( 'taxonomy' => 'product_cat', 'parent' => $top->term_id, 'hide_empty' => true, 'orderby' => 'term_id' ) );
		if ( ! $kids || is_wp_error( $kids ) ) {
			return '';
		}
		$out .= $chip( $top, 'הכול', $here->term_id === $top->term_id );
		foreach ( $kids as $k ) {
			$out .= $chip( $k, $k->name, $here->term_id === $k->term_id );
		}
	} else {
		$tops = get_terms( array( 'taxonomy' => 'product_cat', 'parent' => 0, 'hide_empty' => true, 'orderby' => 'term_id', 'exclude' => array( (int) get_option( 'default_product_cat' ) ) ) );
		foreach ( (array) $tops as $k ) {
			$out .= $chip( $k, $k->name, false );
		}
	}
	return '<nav class="chips" aria-label="קטגוריות">' . $out . '</nav>';
} );

// contact form: sends to the store's email (Settings → General), no extra plugin
add_shortcode( 'lev_contact', function ( $atts = array() ) {
	$cancel = isset( $atts['type'] ) && 'cancel' === $atts['type'];
	$note = '';
	if ( 'POST' === $_SERVER['REQUEST_METHOD'] && isset( $_POST['lev_contact_nonce'] ) && wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['lev_contact_nonce'] ) ), 'lev_contact' ) ) {
		$name  = sanitize_text_field( wp_unslash( $_POST['lev_name'] ?? '' ) );
		$phone = sanitize_text_field( wp_unslash( $_POST['lev_phone'] ?? '' ) );
		$msg   = sanitize_textarea_field( wp_unslash( $_POST['lev_msg'] ?? '' ) );
		$order = sanitize_text_field( wp_unslash( $_POST['lev_order'] ?? '' ) );
		if ( ! empty( $_POST['lev_site'] ) ) { // the hidden field is filled only by bots
			$note = '';
		} elseif ( $name && ( $phone || $msg ) ) {
			$email = sanitize_email( wp_unslash( $_POST['lev_msg_email'] ?? '' ) );
			wp_mail( get_option( 'admin_email' ), ( $cancel ? 'בקשת ביטול עסקה — ' : 'הודעה חדשה מהאתר — ' ) . $name, "שם: {$name}\nטלפון: {$phone}\nאימייל: {$email}\nמספר הזמנה: {$order}\n\n{$msg}" );
			$note = '<p class="lev-note ok">' . ( $cancel ? 'בקשת הביטול התקבלה. נחזור אליך לאישור תוך יום עסקים.' : 'תודה! ההודעה נשלחה ונחזור אליך בהקדם.' ) . '</p>';
		} else {
			$note = '<p class="lev-note err">נא למלא שם, וטלפון או הודעה.</p>';
		}
	}
	return $note . '<form class="lev-form" method="post">'
		. '<label><span>שם</span><input name="lev_name" autocomplete="name" required></label>'
		. '<label><span>טלפון</span><input name="lev_phone" type="tel" autocomplete="tel"></label>'
		. ( $cancel ? '<label><span>מספר הזמנה</span><input name="lev_order"></label><label><span>אימייל</span><input name="lev_msg_email" type="email"></label>' : '' )
		. '<label class="full"><span>' . ( $cancel ? 'מה תרצו לבטל? (אופציונלי)' : 'הודעה' ) . '</span><textarea name="lev_msg" rows="5"></textarea></label>'
		. '<input class="hp" name="lev_site" tabindex="-1" autocomplete="off" aria-hidden="true">'
		. wp_nonce_field( 'lev_contact', 'lev_contact_nonce', true, false )
		. '<button class="wp-element-button" type="submit">' . ( $cancel ? 'שליחת בקשת ביטול' : 'שליחה' ) . '</button></form>';
} );

// order emails in the shop's colours
add_filter( 'woocommerce_email_footer_text', function () {
	return 'לב היהדות · אמנות שמחברת את הנשמה';
} );

// a category with groups shows each group as its own section (heading + its products), as in the approved design;
// the template's flat grid is hidden on those pages (body class lev-grouped)
function lev_children( $term ) {
	if ( ! ( $term instanceof WP_Term ) || $term->parent ) {
		return array();
	}
	$kids = get_terms( array( 'taxonomy' => 'product_cat', 'parent' => $term->term_id, 'hide_empty' => true, 'orderby' => 'term_id' ) ); // Shoval's own order
	return is_wp_error( $kids ) ? array() : $kids;
}
add_filter( 'body_class', function ( $c ) {
	if ( is_product_category() && lev_children( get_queried_object() ) ) {
		$c[] = 'lev-grouped';
	}
	return $c;
} );
add_shortcode( 'lev_groups', function () {
	$kids = lev_children( get_queried_object() );
	if ( ! $kids ) {
		return '';
	}
	$out = '';
	foreach ( $kids as $k ) {
		$out .= '<section class="lev-group"><h2><a href="' . esc_url( get_term_link( $k ) ) . '">' . esc_html( $k->name ) . '</a><span class="count">' . (int) $k->count . ' פריטים</span></h2>'
			. do_shortcode( '[products category="' . esc_attr( $k->slug ) . '" columns="4" limit="-1" orderby="title" order="ASC"]' ) . '</section>';
	}
	return '<div class="lev-groups">' . $out . '</div>';
} );

// no reviews section under products until the shop has real customers (an empty review form under every product looks unfinished)
add_filter( 'woocommerce_product_tabs', function ( $tabs ) {
	unset( $tabs['reviews'] );
	return $tabs;
}, 98 );
add_filter( 'comments_open', function ( $open, $post_id ) {
	return 'product' === get_post_type( $post_id ) ? false : $open;
}, 10, 2 );

// page cache (wp-content/advanced-cache.php): empty it whenever anything a visitor sees changes
function lev_cache_clear() {
	$dir = WP_CONTENT_DIR . '/cache/lev/';
	foreach ( (array) glob( $dir . '*.html' ) as $f ) {
		@unlink( $f );
	}
}
foreach ( array( 'save_post', 'deleted_post', 'trashed_post', 'edited_term', 'created_term', 'delete_term', 'woocommerce_update_product', 'switch_theme', 'customize_save_after', 'update_option_lev_pricelist', 'update_option_lev_addons', 'update_option_blogname', 'update_option_blogdescription' ) as $lev_hook ) {
	add_action( $lev_hook, 'lev_cache_clear' );
}

// every product of the shop / a category on one page (no slow "next page"); the template grids inherit this query
add_action( 'pre_get_posts', function ( $q ) {
	if ( ! is_admin() && $q->is_main_query() && ( $q->is_post_type_archive( 'product' ) || $q->is_tax( array( 'product_cat', 'product_tag' ) ) || ( $q->is_search() && 'product' === $q->get( 'post_type' ) ) ) ) {
		$q->set( 'posts_per_page', 150 );
	}
} );
add_filter( 'loop_shop_per_page', function () { return 150; }, 20 );
