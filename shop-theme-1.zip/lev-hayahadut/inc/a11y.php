<?php
// לב היהדות — accessibility menu (2026-10-25). Copied into the theme as inc/a11y.php by build-wp-theme.cjs.
// A floating button that opens a small menu: text size, high contrast, readable font, underlined links, stop
// animations, grayscale, reset, and a link to the accessibility statement. Choices are kept in the visitor's
// browser only. No plugin, no outside service.

add_action( 'wp_footer', function () {
	$statement = home_url( '/accessibility/' );
	?>
	<div class="lev-a11y" dir="rtl">
		<button type="button" class="lev-a11y-btn" aria-expanded="false" aria-controls="lev-a11y-menu" aria-label="תפריט נגישות">
			<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="4.5" r="2"/><path d="M5 8.5l7 1.5 7-1.5M12 10v4.5M12 14.5l-3 6M12 14.5l3 6"/></svg>
		</button>
		<div class="lev-a11y-menu" id="lev-a11y-menu" role="dialog" aria-label="נגישות" hidden>
			<div class="lev-a11y-head"><b>נגישות</b><button type="button" class="lev-a11y-close" aria-label="סגירת תפריט הנגישות">×</button></div>
			<div class="lev-a11y-size" role="group" aria-label="גודל טקסט">
				<button type="button" data-a11y-size="-1" aria-label="הקטנת טקסט">א−</button>
				<span>גודל טקסט</span>
				<button type="button" data-a11y-size="1" aria-label="הגדלת טקסט">א+</button>
			</div>
			<button type="button" class="lev-a11y-opt" data-a11y="contrast" aria-pressed="false">ניגודיות גבוהה</button>
			<button type="button" class="lev-a11y-opt" data-a11y="font" aria-pressed="false">גופן קריא</button>
			<button type="button" class="lev-a11y-opt" data-a11y="links" aria-pressed="false">הדגשת קישורים</button>
			<button type="button" class="lev-a11y-opt" data-a11y="still" aria-pressed="false">עצירת אנימציות</button>
			<button type="button" class="lev-a11y-opt" data-a11y="gray" aria-pressed="false">גווני אפור</button>
			<button type="button" class="lev-a11y-reset">איפוס</button>
			<a class="lev-a11y-link" href="<?php echo esc_url( $statement ); ?>">הצהרת נגישות</a>
		</div>
	</div>
	<script>
	(function () {
		var root = document.documentElement, KEY = 'lev-a11y';
		var state = { size: 0, contrast: false, font: false, links: false, still: false, gray: false };
		try { var saved = JSON.parse(localStorage.getItem(KEY) || 'null'); if (saved) for (var k in saved) state[k] = saved[k]; } catch (e) {}
		var box = document.querySelector('.lev-a11y'), btn = box.querySelector('.lev-a11y-btn'), menu = box.querySelector('.lev-a11y-menu');
		function apply() {
			root.style.fontSize = state.size ? (100 + state.size * 12.5) + '%' : '';
			['contrast', 'font', 'links', 'still', 'gray'].forEach(function (k) {
				root.classList.toggle('a11y-' + k, !!state[k]);
				var b = menu.querySelector('[data-a11y="' + k + '"]'); if (b) b.setAttribute('aria-pressed', state[k] ? 'true' : 'false');
			});
			try { localStorage.setItem(KEY, JSON.stringify(state)); } catch (e) {}
		}
		function toggle(open) {
			menu.hidden = !open; btn.setAttribute('aria-expanded', open ? 'true' : 'false');
			if (open) menu.querySelector('button').focus(); else btn.focus();
		}
		btn.addEventListener('click', function () { toggle(menu.hidden); });
		box.querySelector('.lev-a11y-close').addEventListener('click', function () { toggle(false); });
		document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && !menu.hidden) toggle(false); });
		menu.addEventListener('click', function (e) {
			var t = e.target.closest('button'); if (!t) return;
			if (t.dataset.a11ySize) state.size = Math.max(-1, Math.min(4, state.size + parseInt(t.dataset.a11ySize, 10)));
			else if (t.dataset.a11y) state[t.dataset.a11y] = !state[t.dataset.a11y];
			else if (t.classList.contains('lev-a11y-reset')) state = { size: 0, contrast: false, font: false, links: false, still: false, gray: false };
			apply();
		});
		apply();
	})();
	</script>
	<?php
} );
