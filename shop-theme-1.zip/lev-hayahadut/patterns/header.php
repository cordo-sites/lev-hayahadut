<?php
/**
 * Title: כותרת האתר
 * Slug: lev-hayahadut/header
 * Inserter: no
 * Categories: lev-hayahadut
 */
?>
<!-- wp:group {"className":"ann","layout":{"type":"default"}} -->
<div class="wp-block-group ann"><!-- wp:paragraph -->
<p><strong>משלוחים לכל הארץ</strong> · שירות אישי לכל הזמנה · החזרה והחלפה בקלות</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
<!-- wp:group {"className":"site-head","layout":{"type":"default"}} -->
<div class="wp-block-group site-head"><!-- wp:group {"className":"bar","layout":{"type":"default"}} -->
<div class="wp-block-group bar"><!-- wp:group {"className":"brand","layout":{"type":"default"}} -->
<div class="wp-block-group brand"><!-- wp:image {"sizeSlug":"full","linkDestination":"custom","className":"logo-mark"} -->
<figure class="wp-block-image size-full logo-mark"><a href="<?php echo esc_url( home_url( '/' ) ); ?>"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/icons/logo.svg' ) ); ?>" alt=""/></a></figure>
<!-- /wp:image -->
<!-- wp:group {"className":"brand-text","layout":{"type":"default"}} -->
<div class="wp-block-group brand-text"><!-- wp:site-title {"level":0,"className":"brand-name"} /-->
<!-- wp:paragraph {"className":"tagline"} -->
<p class="tagline">אמנות שמחברת את הנשמה</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
<!-- wp:navigation {"overlayMenu":"mobile","className":"main-nav","layout":{"type":"flex","justifyContent":"right"}} -->
<!-- wp:navigation-link {"label":"דף הבית","url":"/","kind":"custom","isTopLevelLink":true} /-->
<!-- wp:navigation-submenu {"label":"קטגוריות","url":"/shop/","kind":"custom"} -->
<!-- wp:navigation-link {"label":"עיצובים לבית יהודי","url":"/product-category/home-designs/","kind":"custom"} /-->
<!-- wp:navigation-link {"label":"תמונות צדיקים","url":"/product-category/tzadikim/","kind":"custom"} /-->
<!-- wp:navigation-link {"label":"שבת","url":"/product-category/shabbat/","kind":"custom"} /-->
<!-- wp:navigation-link {"label":"חגים","url":"/product-category/chagim/","kind":"custom"} /-->
<!-- wp:navigation-link {"label":"לבית הכנסת","url":"/product-category/beit-knesset/","kind":"custom"} /-->
<!-- wp:navigation-link {"label":"תשמישי קדושה","url":"/product-category/tashmishei-kedusha/","kind":"custom"} /-->
<!-- wp:navigation-link {"label":"מתנות יהודיות","url":"/product-category/gifts/","kind":"custom"} /-->
<!-- wp:navigation-link {"label":"קופות צדקה","url":"/product-category/tzedaka/","kind":"custom"} /-->
<!-- /wp:navigation-submenu -->
<!-- wp:navigation-link {"label":"כל המוצרים","url":"/shop/","kind":"custom","isTopLevelLink":true} /-->
<!-- wp:navigation-link {"label":"אודות","url":"/#about","kind":"custom","isTopLevelLink":true} /-->
<!-- wp:navigation-link {"label":"שאלות","url":"/#faq","kind":"custom","isTopLevelLink":true} /-->
<!-- wp:navigation-link {"label":"צור קשר","url":"/contact/","kind":"custom","isTopLevelLink":true} /-->
<!-- /wp:navigation -->
<!-- wp:search {"label":"חיפוש","showLabel":false,"placeholder":"חיפוש בין 108 פריטים…","buttonText":"חיפוש","buttonPosition":"button-inside","buttonUseIcon":true,"query":{"post_type":"product"},"className":"site-search"} /-->
<!-- wp:group {"className":"tools","layout":{"type":"default"}} -->
<div class="wp-block-group tools"><!-- wp:woocommerce/customer-account {"displayStyle":"icon_only","iconStyle":"line","iconClass":"wc-block-customer-account__account-icon"} /-->
<!-- wp:woocommerce/mini-cart /-->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
