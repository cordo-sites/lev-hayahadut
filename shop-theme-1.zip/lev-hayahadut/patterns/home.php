<?php
/**
 * Title: דף הבית — לב היהדות
 * Slug: lev-hayahadut/home
 * Inserter: yes
 * Categories: lev-hayahadut
 */
?>
<!-- wp:group {"tagName":"section","anchor":"hero","className":"hero","layout":{"type":"default"}} -->
<section id="hero" class="wp-block-group hero"><!-- wp:group {"className":"panel","layout":{"type":"default"}} -->
<div class="wp-block-group panel"><!-- wp:paragraph {"className":"eyebrow"} -->
<p class="eyebrow">אמנות יהודית · יודאיקה · מתנות</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":1,"className":"hero-title"} -->
<h1 class="wp-block-heading hero-title">אמנות יהודית</h1>
<!-- /wp:heading -->
<!-- wp:paragraph {"className":"hero-sub"} -->
<p class="hero-sub">שנוגעת בלב</p>
<!-- /wp:paragraph -->
<!-- wp:paragraph {"className":"hero-text"} -->
<p class="hero-text">תמונות, ברכות ויודאיקה שנבחרו ביד — בשחור, לבן וזהב. כל פריט בגדלים ובצבעים לבחירה.</p>
<!-- /wp:paragraph -->
<!-- wp:buttons {"className":"gold-btn"} -->
<div class="wp-block-buttons gold-btn"><!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="/shop/">לכל המוצרים</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons -->
<!-- wp:group {"className":"feats","layout":{"type":"default"}} -->
<div class="wp-block-group feats"><!-- wp:group {"className":"feat","layout":{"type":"default"}} -->
<div class="wp-block-group feat"><!-- wp:image {"sizeSlug":"full","linkDestination":"none","className":"feat-icon"} -->
<figure class="wp-block-image size-full feat-icon"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/icons/f-personal.svg' ) ); ?>" alt=""/></figure>
<!-- /wp:image -->
<!-- wp:paragraph -->
<p>התאמה אישית — שם או הקדשה</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
<!-- wp:group {"className":"feat","layout":{"type":"default"}} -->
<div class="wp-block-group feat"><!-- wp:image {"sizeSlug":"full","linkDestination":"none","className":"feat-icon"} -->
<figure class="wp-block-image size-full feat-icon"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/icons/f-gift.svg' ) ); ?>" alt=""/></figure>
<!-- /wp:image -->
<!-- wp:paragraph -->
<p>אריזת מתנה מהודרת</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
<!-- wp:group {"className":"feat","layout":{"type":"default"}} -->
<div class="wp-block-group feat"><!-- wp:image {"sizeSlug":"full","linkDestination":"none","className":"feat-icon"} -->
<figure class="wp-block-image size-full feat-icon"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/icons/f-catalog.svg' ) ); ?>" alt=""/></figure>
<!-- /wp:image -->
<!-- wp:paragraph -->
<p>108 פריטים</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
<!-- wp:image {"sizeSlug":"full","linkDestination":"none","className":"hero-pic"} -->
<figure class="wp-block-image size-full hero-pic"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/img/hero.webp' ) ); ?>" alt="קנבס אם אשכחך ירושלים בסלון"/></figure>
<!-- /wp:image -->
</section>
<!-- /wp:group -->
<!-- wp:group {"tagName":"section","anchor":"cats","className":"cats","layout":{"type":"default"}} -->
<section id="cats" class="wp-block-group cats"><!-- wp:paragraph {"className":"eyebrow"} -->
<p class="eyebrow">הקטגוריות שלנו · 108 פריטים</p>
<!-- /wp:paragraph -->
<!-- wp:group {"className":"circles","layout":{"type":"default"}} -->
<div class="wp-block-group circles"><!-- wp:group {"className":"circ","layout":{"type":"default"}} -->
<div class="wp-block-group circ"><!-- wp:image {"sizeSlug":"full","linkDestination":"custom","className":"ball"} -->
<figure class="wp-block-image size-full ball"><a href="<?php echo esc_url( home_url( '/product-category/home-designs/' ) ); ?>"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/icons/home-designs.svg' ) ); ?>" alt=""/></a></figure>
<!-- /wp:image -->
<!-- wp:paragraph -->
<p><a href="<?php echo esc_url( home_url( '/product-category/home-designs/' ) ); ?>">עיצובים לבית יהודי</a></p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
<!-- wp:group {"className":"circ","layout":{"type":"default"}} -->
<div class="wp-block-group circ"><!-- wp:image {"sizeSlug":"full","linkDestination":"custom","className":"ball"} -->
<figure class="wp-block-image size-full ball"><a href="<?php echo esc_url( home_url( '/product-category/tzadikim/' ) ); ?>"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/icons/tzadikim.svg' ) ); ?>" alt=""/></a></figure>
<!-- /wp:image -->
<!-- wp:paragraph -->
<p><a href="<?php echo esc_url( home_url( '/product-category/tzadikim/' ) ); ?>">תמונות צדיקים</a></p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
<!-- wp:group {"className":"circ","layout":{"type":"default"}} -->
<div class="wp-block-group circ"><!-- wp:image {"sizeSlug":"full","linkDestination":"custom","className":"ball"} -->
<figure class="wp-block-image size-full ball"><a href="<?php echo esc_url( home_url( '/product-category/shabbat/' ) ); ?>"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/icons/shabbat.svg' ) ); ?>" alt=""/></a></figure>
<!-- /wp:image -->
<!-- wp:paragraph -->
<p><a href="<?php echo esc_url( home_url( '/product-category/shabbat/' ) ); ?>">שבת</a></p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
<!-- wp:group {"className":"circ","layout":{"type":"default"}} -->
<div class="wp-block-group circ"><!-- wp:image {"sizeSlug":"full","linkDestination":"custom","className":"ball"} -->
<figure class="wp-block-image size-full ball"><a href="<?php echo esc_url( home_url( '/product-category/chagim/' ) ); ?>"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/icons/chagim.svg' ) ); ?>" alt=""/></a></figure>
<!-- /wp:image -->
<!-- wp:paragraph -->
<p><a href="<?php echo esc_url( home_url( '/product-category/chagim/' ) ); ?>">חגים</a></p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
<!-- wp:group {"className":"circ","layout":{"type":"default"}} -->
<div class="wp-block-group circ"><!-- wp:image {"sizeSlug":"full","linkDestination":"custom","className":"ball"} -->
<figure class="wp-block-image size-full ball"><a href="<?php echo esc_url( home_url( '/product-category/beit-knesset/' ) ); ?>"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/icons/beit-knesset.svg' ) ); ?>" alt=""/></a></figure>
<!-- /wp:image -->
<!-- wp:paragraph -->
<p><a href="<?php echo esc_url( home_url( '/product-category/beit-knesset/' ) ); ?>">לבית הכנסת</a></p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
<!-- wp:group {"className":"circ","layout":{"type":"default"}} -->
<div class="wp-block-group circ"><!-- wp:image {"sizeSlug":"full","linkDestination":"custom","className":"ball"} -->
<figure class="wp-block-image size-full ball"><a href="<?php echo esc_url( home_url( '/product-category/tashmishei-kedusha/' ) ); ?>"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/icons/tashmishei-kedusha.svg' ) ); ?>" alt=""/></a></figure>
<!-- /wp:image -->
<!-- wp:paragraph -->
<p><a href="<?php echo esc_url( home_url( '/product-category/tashmishei-kedusha/' ) ); ?>">תשמישי קדושה</a></p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
<!-- wp:group {"className":"circ","layout":{"type":"default"}} -->
<div class="wp-block-group circ"><!-- wp:image {"sizeSlug":"full","linkDestination":"custom","className":"ball"} -->
<figure class="wp-block-image size-full ball"><a href="<?php echo esc_url( home_url( '/product-category/gifts/' ) ); ?>"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/icons/gifts.svg' ) ); ?>" alt=""/></a></figure>
<!-- /wp:image -->
<!-- wp:paragraph -->
<p><a href="<?php echo esc_url( home_url( '/product-category/gifts/' ) ); ?>">מתנות יהודיות</a></p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
<!-- wp:group {"className":"circ","layout":{"type":"default"}} -->
<div class="wp-block-group circ"><!-- wp:image {"sizeSlug":"full","linkDestination":"custom","className":"ball"} -->
<figure class="wp-block-image size-full ball"><a href="<?php echo esc_url( home_url( '/product-category/tzedaka/' ) ); ?>"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/icons/tzedaka.svg' ) ); ?>" alt=""/></a></figure>
<!-- /wp:image -->
<!-- wp:paragraph -->
<p><a href="<?php echo esc_url( home_url( '/product-category/tzedaka/' ) ); ?>">קופות צדקה</a></p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->
<!-- wp:group {"tagName":"section","anchor":"trust","className":"trust","layout":{"type":"default"}} -->
<section id="trust" class="wp-block-group trust"><!-- wp:group {"className":"wrap trust-row","layout":{"type":"default"}} -->
<div class="wp-block-group wrap trust-row"><!-- wp:group {"className":"t","layout":{"type":"default"}} -->
<div class="wp-block-group t"><!-- wp:image {"sizeSlug":"full","linkDestination":"none","className":"t-icon"} -->
<figure class="wp-block-image size-full t-icon"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/icons/t-1.svg' ) ); ?>" alt=""/></figure>
<!-- /wp:image -->
<!-- wp:paragraph {"className":"t-b"} -->
<p class="t-b">מעוצב עם נשמה</p>
<!-- /wp:paragraph -->
<!-- wp:paragraph {"className":"t-s"} -->
<p class="t-s">כל פריט נבחר ביד</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
<!-- wp:group {"className":"t","layout":{"type":"default"}} -->
<div class="wp-block-group t"><!-- wp:image {"sizeSlug":"full","linkDestination":"none","className":"t-icon"} -->
<figure class="wp-block-image size-full t-icon"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/icons/t-2.svg' ) ); ?>" alt=""/></figure>
<!-- /wp:image -->
<!-- wp:paragraph {"className":"t-b"} -->
<p class="t-b">איכות ללא פשרות</p>
<!-- /wp:paragraph -->
<!-- wp:paragraph {"className":"t-s"} -->
<p class="t-s">חומרים וגימור מוקפדים</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
<!-- wp:group {"className":"t","layout":{"type":"default"}} -->
<div class="wp-block-group t"><!-- wp:image {"sizeSlug":"full","linkDestination":"none","className":"t-icon"} -->
<figure class="wp-block-image size-full t-icon"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/icons/t-3.svg' ) ); ?>" alt=""/></figure>
<!-- /wp:image -->
<!-- wp:paragraph {"className":"t-b"} -->
<p class="t-b">משלוח מהיר</p>
<!-- /wp:paragraph -->
<!-- wp:paragraph {"className":"t-s"} -->
<p class="t-s">עד הבית בכל הארץ</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
<!-- wp:group {"className":"t","layout":{"type":"default"}} -->
<div class="wp-block-group t"><!-- wp:image {"sizeSlug":"full","linkDestination":"none","className":"t-icon"} -->
<figure class="wp-block-image size-full t-icon"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/icons/t-4.svg' ) ); ?>" alt=""/></figure>
<!-- /wp:image -->
<!-- wp:paragraph {"className":"t-b"} -->
<p class="t-b">קנייה בטוחה</p>
<!-- /wp:paragraph -->
<!-- wp:paragraph {"className":"t-s"} -->
<p class="t-s">תשלום מאובטח</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->
<!-- wp:group {"tagName":"section","anchor":"picks","className":"picks","layout":{"type":"default"}} -->
<section id="picks" class="wp-block-group picks"><!-- wp:group {"className":"head","layout":{"type":"default"}} -->
<div class="wp-block-group head"><!-- wp:paragraph {"className":"eyebrow"} -->
<p class="eyebrow">מוצרים נבחרים</p>
<!-- /wp:paragraph -->
<!-- wp:heading -->
<h2 class="wp-block-heading">הפריטים שהכי אוהבים</h2>
<!-- /wp:heading -->
<!-- wp:paragraph {"className":"sub"} -->
<p class="sub">מה שלקוחות שלנו בוחרים הכי הרבה</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
<!-- wp:woocommerce/product-collection {"queryId":11,"query":{"perPage":6,"pages":1,"offset":0,"postType":"product","order":"asc","orderBy":"title","search":"","exclude":[],"inherit":false,"taxQuery":[],"isProductCollectionBlock":true,"featured":true,"woocommerceOnSale":false,"woocommerceStockStatus":["instock","outofstock","onbackorder"],"woocommerceAttributes":[],"woocommerceHandPickedProducts":[],"filterable":false},"tagName":"div","displayLayout":{"type":"flex","columns":6,"shrinkColumns":true},"dimensions":{"widthType":"fill"},"collection":"woocommerce/product-collection/featured","hideControls":["inherit","featured"],"queryContextIncludes":["collection"],"className":"cards"} -->
<div class="wp-block-woocommerce-product-collection cards"><!-- wp:woocommerce/product-template -->
<!-- wp:woocommerce/product-image {"showSaleBadge":false,"imageSizing":"thumbnail","isDescendentOfQueryLoop":true} /-->
<!-- wp:post-title {"textAlign":"center","level":3,"isLink":true,"__woocommerceNamespace":"woocommerce/product-collection/product-title"} /-->
<!-- wp:woocommerce/product-price {"isDescendentOfQueryLoop":true,"textAlign":"center"} /-->
<!-- /wp:woocommerce/product-template --></div>
<!-- /wp:woocommerce/product-collection -->
<!-- wp:paragraph {"className":"all"} -->
<p class="all"><a href="/shop/">צפייה בכל המוצרים ←</a></p>
<!-- /wp:paragraph -->
</section>
<!-- /wp:group -->
<!-- wp:group {"tagName":"section","anchor":"about","className":"about","layout":{"type":"default"}} -->
<section id="about" class="wp-block-group about"><!-- wp:group {"className":"wrap two","layout":{"type":"default"}} -->
<div class="wp-block-group wrap two"><!-- wp:group {"className":"","layout":{"type":"default"}} -->
<div class="wp-block-group"><!-- wp:paragraph {"className":"eyebrow"} -->
<p class="eyebrow">קצת עלינו</p>
<!-- /wp:paragraph -->
<!-- wp:heading -->
<h2 class="wp-block-heading">יודאיקה שנוגעת בלב</h2>
<!-- /wp:heading -->
<!-- wp:paragraph -->
<p>לב היהדות נולדה מאהבה לבית היהודי — לברכה שתלויה בכניסה, לתמונת הצדיק שמלווה את המשפחה, לפמוטים שמדליקים בכל ערב שבת.</p>
<!-- /wp:paragraph -->
<!-- wp:paragraph -->
<p>כל תמונה מודפסת על זכוכית מחוסמת או על קנבס מתוח על עץ, במגוון מידות לאורך, לרוחב ובפורמט פנורמי — כדי שתתאים בדיוק לקיר שלכם.</p>
<!-- /wp:paragraph -->
<!-- wp:paragraph -->
<p>רוצים שם משפחה, הקדשה או מידה מיוחדת? <a href="/contact/">כתבו לנו</a> ונכין בשבילכם.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
<!-- wp:group {"className":"quote","layout":{"type":"default"}} -->
<div class="wp-block-group quote"><!-- wp:paragraph {"className":"verse"} -->
<p class="verse">בָּרוּךְ אַתָּה בְּבֹאֶךָ<br>וּבָרוּךְ אַתָּה בְּצֵאתֶךָ</p>
<!-- /wp:paragraph -->
<!-- wp:paragraph {"className":"src"} -->
<p class="src">דברים כ״ח · ו׳</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->
<!-- wp:group {"tagName":"section","anchor":"faq","className":"faq","layout":{"type":"default"}} -->
<section id="faq" class="wp-block-group faq"><!-- wp:group {"className":"wrap narrow","layout":{"type":"default"}} -->
<div class="wp-block-group wrap narrow"><!-- wp:paragraph {"className":"eyebrow"} -->
<p class="eyebrow">שאלות נפוצות</p>
<!-- /wp:paragraph -->
<!-- wp:heading -->
<h2 class="wp-block-heading">רוצים לשאול משהו?</h2>
<!-- /wp:heading -->
<!-- wp:details {"showContent":true} -->
<details class="wp-block-details" open><summary>איך מזמינים?</summary><!-- wp:paragraph -->
<p>בוחרים פריט, בוחרים סוג הדפסה ומידה, מוסיפים לסל ומשלמים בתשלום מאובטח.</p>
<!-- /wp:paragraph -->
</details>
<!-- /wp:details -->
<!-- wp:details -->
<details class="wp-block-details"><summary>מה ההבדל בין זכוכית לקנבס?</summary><!-- wp:paragraph -->
<p>זכוכית מחוסמת — מראה מבריק ויוקרתי, נתלית עם ברגים מעוצבים שכלולים במחיר. קנבס מתוח על עץ — מראה של ציור, מט וחם, ומגיע מוכן לתלייה.</p>
<!-- /wp:paragraph -->
</details>
<!-- /wp:details -->
<!-- wp:details -->
<details class="wp-block-details"><summary>איך יודעים איזו מידה מתאימה?</summary><!-- wp:paragraph -->
<p>בכל תמונה יש כפתור "איך זה ייראה אצלי על הקיר?" — מעלים תמונה של הקיר ורואים את התמונה עליו, בפרופורציה של המידה שבחרתם.</p>
<!-- /wp:paragraph -->
</details>
<!-- /wp:details -->
<!-- wp:details -->
<details class="wp-block-details"><summary>אפשר להתאים אישית — שם, הקדשה, גודל אחר?</summary><!-- wp:paragraph -->
<p>כן. ברכות ושלטים אפשר להתאים עם שם המשפחה או הקדשה, וגדלים מיוחדים לפי בקשה. <a href="/contact/">כתבו לנו</a>.</p>
<!-- /wp:paragraph -->
</details>
<!-- /wp:details -->
<!-- wp:details -->
<details class="wp-block-details"><summary>אפשר להזמין התקנה?</summary><!-- wp:paragraph -->
<p>כן — בעמוד של כל תמונה מסמנים "התקנה על הקיר" והמחיר מתעדכן.</p>
<!-- /wp:paragraph -->
</details>
<!-- /wp:details -->
<!-- wp:details -->
<details class="wp-block-details"><summary>כמה זמן לוקח המשלוח?</summary><!-- wp:paragraph -->
<p>משלוח עד הבית לכל הארץ. זמני האספקה המדויקים יעודכנו כאן.</p>
<!-- /wp:paragraph -->
</details>
<!-- /wp:details -->
<!-- wp:details -->
<details class="wp-block-details"><summary>מה אם הפריט הגיע פגום?</summary><!-- wp:paragraph -->
<p>מחליפים. פרטים מלאים ב<a href="/returns/">מדיניות ההחזרות</a>.</p>
<!-- /wp:paragraph -->
</details>
<!-- /wp:details -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->
<!-- wp:group {"tagName":"section","anchor":"contact","className":"contact","layout":{"type":"default"}} -->
<section id="contact" class="wp-block-group contact"><!-- wp:group {"className":"wrap narrow","layout":{"type":"default"}} -->
<div class="wp-block-group wrap narrow"><!-- wp:paragraph {"className":"eyebrow"} -->
<p class="eyebrow">צור קשר</p>
<!-- /wp:paragraph -->
<!-- wp:heading -->
<h2 class="wp-block-heading">נשמח לעזור</h2>
<!-- /wp:heading -->
<!-- wp:paragraph -->
<p>שאלה על פריט, התאמה אישית או הזמנה גדולה — טלפון: יעודכן · אימייל: יעודכן</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->
