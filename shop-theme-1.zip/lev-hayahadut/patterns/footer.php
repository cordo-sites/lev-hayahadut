<?php
/**
 * Title: תחתית האתר
 * Slug: lev-hayahadut/footer
 * Inserter: no
 * Categories: lev-hayahadut
 */
?>
<!-- wp:group {"tagName":"footer","className":"site-foot","layout":{"type":"default"}} -->
<footer class="wp-block-group site-foot"><!-- wp:group {"className":"wrap fgrid","layout":{"type":"default"}} -->
<div class="wp-block-group wrap fgrid"><!-- wp:group {"className":"","layout":{"type":"default"}} -->
<div class="wp-block-group"><!-- wp:heading {"level":4} -->
<h4 class="wp-block-heading">לב היהדות</h4>
<!-- /wp:heading -->
<!-- wp:paragraph -->
<p>אמנות יהודית, יודאיקה ומתנות עם משמעות — בשחור, לבן וזהב.</p>
<!-- /wp:paragraph -->
<!-- wp:paragraph {"className":"biz"} -->
<p class="biz">[שם העסק] · עוסק מס' [___] · [כתובת]</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
<!-- wp:group {"className":"","layout":{"type":"default"}} -->
<div class="wp-block-group"><!-- wp:paragraph {"className":"eyebrow"} -->
<p class="eyebrow">קטגוריות</p>
<!-- /wp:paragraph -->
<!-- wp:list -->
<ul class="wp-block-list"><!-- wp:list-item -->
<li><a href="<?php echo esc_url( home_url( '/product-category/home-designs/' ) ); ?>">עיצובים לבית יהודי</a></li>
<!-- /wp:list-item --><!-- wp:list-item -->
<li><a href="<?php echo esc_url( home_url( '/product-category/tzadikim/' ) ); ?>">תמונות צדיקים</a></li>
<!-- /wp:list-item --><!-- wp:list-item -->
<li><a href="<?php echo esc_url( home_url( '/product-category/shabbat/' ) ); ?>">שבת</a></li>
<!-- /wp:list-item --><!-- wp:list-item -->
<li><a href="<?php echo esc_url( home_url( '/product-category/chagim/' ) ); ?>">חגים</a></li>
<!-- /wp:list-item --><!-- wp:list-item -->
<li><a href="<?php echo esc_url( home_url( '/product-category/beit-knesset/' ) ); ?>">לבית הכנסת</a></li>
<!-- /wp:list-item --><!-- wp:list-item -->
<li><a href="<?php echo esc_url( home_url( '/product-category/tashmishei-kedusha/' ) ); ?>">תשמישי קדושה</a></li>
<!-- /wp:list-item --><!-- wp:list-item -->
<li><a href="<?php echo esc_url( home_url( '/product-category/gifts/' ) ); ?>">מתנות יהודיות</a></li>
<!-- /wp:list-item --><!-- wp:list-item -->
<li><a href="<?php echo esc_url( home_url( '/product-category/tzedaka/' ) ); ?>">קופות צדקה</a></li>
<!-- /wp:list-item --></ul>
<!-- /wp:list -->
</div>
<!-- /wp:group -->
<!-- wp:group {"className":"","layout":{"type":"default"}} -->
<div class="wp-block-group"><!-- wp:paragraph {"className":"eyebrow"} -->
<p class="eyebrow">יצירת קשר</p>
<!-- /wp:paragraph -->
<!-- wp:list -->
<ul class="wp-block-list"><!-- wp:list-item -->
<li>טלפון: יעודכן</li>
<!-- /wp:list-item --><!-- wp:list-item -->
<li>אימייל: יעודכן</li>
<!-- /wp:list-item --><!-- wp:list-item -->
<li>שעות פעילות: יעודכן</li>
<!-- /wp:list-item --><!-- wp:list-item -->
<li>משלוחים לכל הארץ</li>
<!-- /wp:list-item --></ul>
<!-- /wp:list -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
<!-- wp:group {"className":"wrap copy","layout":{"type":"default"}} -->
<div class="wp-block-group wrap copy"><!-- wp:paragraph -->
<p>© לב היהדות</p>
<!-- /wp:paragraph -->
<!-- wp:paragraph {"className":"legal"} -->
<p class="legal"><a class="cancel" href="/cancel/">ביטול עסקה</a> · <a href="/terms/">תקנון</a> · <a href="/returns/">החזרות</a> · <a href="/privacy/">פרטיות</a> · <a href="/accessibility/">הצהרת נגישות</a> · <a href="/contact/">צור קשר</a></p>
<!-- /wp:paragraph -->
<!-- wp:paragraph -->
<p>עיצוב ובנייה: Cordo</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
</footer>
<!-- /wp:group -->
