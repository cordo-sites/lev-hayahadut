<?php
// לב היהדות — block theme for Shoval's Judaica store. Built by Cordo from design/home-v3.html.
add_action( 'after_setup_theme', function () {
	add_theme_support( 'woocommerce' );
	add_theme_support( 'wc-product-gallery-lightbox' );
	add_theme_support( 'wc-product-gallery-slider' );
	// the editor loads the same font and stylesheet as the site, so Shoval edits what visitors see
	add_editor_style( array( 'https://fonts.googleapis.com/css2?family=Heebo:wght@300;400;500;600;700;800&display=swap', 'style.css' ) );
} );
add_action( 'wp_enqueue_scripts', function () {
	wp_enqueue_style( 'lev-fonts', 'https://fonts.googleapis.com/css2?family=Heebo:wght@300;400;500;600;700;800&display=swap', array(), null );
	wp_enqueue_style( 'lev-style', get_stylesheet_uri(), array(), wp_get_theme()->get( 'Version' ) );
	wp_enqueue_script( 'lev-life', get_theme_file_uri( 'assets/life.js' ), array(), wp_get_theme()->get( 'Version' ), true );
} );
add_action( 'init', function () {
	register_block_pattern_category( 'lev-hayahadut', array( 'label' => 'לב היהדות' ) );
} );
// the admin speaks the shop's font (Heebo) — icon fonts keep their own family
add_action( 'admin_enqueue_scripts', function () {
	wp_enqueue_style( 'lev-admin-font', 'https://fonts.googleapis.com/css2?family=Heebo:wght@300;400;500;600;700;800&display=swap', array(), null );
	wp_add_inline_style( 'lev-admin-font', 'body,body.rtl,.rtl,body.wp-admin,#wpadminbar,#wpadminbar *:not(.ab-icon):not([class*=dashicons]),.wp-core-ui .button,input,select,textarea,h1,h2,h3,h4,.components-button,.components-base-control,.edit-post-header,.editor-header,.interface-interface-skeleton{font-family:Heebo,Arial,sans-serif!important}' );
} );
// the admin home: big shortcuts to everything Shoval edits, instead of WordPress's generic boxes
add_action( 'wp_dashboard_setup', function () {
	global $wp_meta_boxes;
	$wp_meta_boxes['dashboard'] = array(); remove_action( 'welcome_panel', 'wp_welcome_panel' );
	wp_add_dashboard_widget( 'lev_shortcuts', 'לב היהדות — מה לערוך?', function () {
		$links = array(
			array( 'עריכת דף הבית', 'תמונה ראשית, כותרות, טקסטים, שאלות נפוצות', admin_url( 'site-editor.php?p=%2Fwp_template%2Flev-hayahadut%2F%2Ffront-page&canvas=edit' ), 'dashicons-admin-home' ),
			array( 'כל המוצרים', 'שינוי שם, מחיר, תמונה · ⭐ = מוצר נבחר בדף הבית', admin_url( 'edit.php?post_type=product' ), 'dashicons-products' ),
			array( 'הוספת מוצר', 'מוצר חדש — או "העתקה לטיוטה חדשה" ממוצר קיים', admin_url( 'post-new.php?post_type=product' ), 'dashicons-plus-alt' ),
			array( 'קטגוריות', 'שמות הקטגוריות וסדר שלהן', admin_url( 'edit-tags.php?taxonomy=product_cat&post_type=product' ), 'dashicons-category' ),
			array( 'הזמנות', 'כל ההזמנות שהתקבלו', admin_url( 'admin.php?page=wc-orders' ), 'dashicons-cart' ),
			array( 'כותרת ותחתית האתר', 'תפריט, טלפון, מייל, פרטי יצירת קשר', admin_url( 'site-editor.php?p=%2Fpattern&postType=wp_template_part' ), 'dashicons-align-wide' ),
			array( 'צפייה באתר', 'לראות את החנות כמו לקוח', home_url( '/' ), 'dashicons-visibility' ),
		);
		echo '<div class="lev-grid">';
		foreach ( $links as $l ) {
			printf( '<a class="lev-card" href="%s"><span class="dashicons %s"></span><b>%s</b><small>%s</small></a>', esc_url( $l[2] ), esc_attr( $l[3] ), esc_html( $l[0] ), esc_html( $l[1] ) );
		}
		echo '</div>';
	} );
}, 999 ); // after WooCommerce adds its boxes, so ours is the only one
add_action( 'admin_head-index.php', function () {
	echo '<style>#dashboard-widgets .postbox-container{width:100%!important}#lev_shortcuts .inside{padding:6px 12px 16px}.lev-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(230px,1fr));gap:14px}.lev-card{display:flex;flex-direction:column;gap:6px;padding:20px;border:1px solid #e2d9c8;background:#fffdf9;text-decoration:none;color:#1c1915;border-radius:4px;transition:border-color .2s,box-shadow .2s}.lev-card:hover{border-color:#c8a45a;box-shadow:0 10px 24px -14px rgba(60,45,20,.5);color:#1c1915}.lev-card .dashicons{color:#9b7b35;font-size:30px;width:30px;height:30px}.lev-card b{font-size:16px}.lev-card small{color:#766f62;font-size:12.5px;line-height:1.5}#welcome-panel{display:none}</style>';
} );
require get_theme_file_path( 'inc/shop.php' );
require get_theme_file_path( 'inc/addons.php' ); // pictures: format, print type, size, screws, installation, wall preview
require get_theme_file_path( 'inc/a11y.php' ); // accessibility menu
require get_theme_file_path( 'inc/ux.php' ); // login panel, colour boxes, details tab, WhatsApp // verse, category buttons, contact form, email footer
// a product without a photo shows a cream mount with a gold star, not WooCommerce's grey box
add_filter( 'woocommerce_placeholder_img_src', function () {
	return get_theme_file_uri( 'assets/img/placeholder.svg' );
} );
