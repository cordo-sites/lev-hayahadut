<?php
// לב היהדות — wall pictures (Shoval, 2026-10-23). Copied into the theme as inc/addons.php by build-wp-theme.cjs.
//
// Every picture has a FORMAT: אורך (portrait) / רוחב (landscape) / פנורמי (panoramic). The format decides which sizes
// the customer sees; the price comes from one central price list (מוצרים → מחירון תמונות), per format × print type × size.
// Print types: tempered glass, or canvas stretched on a wooden frame (stretching included). Glass: screw colour.
// Both: optional installation. Changing a price in the list changes it on every picture of that format.
// A picture is any product with the meta _lev_format; Shoval picks it in the product screen ("פורמט התמונה").

const LEV_MATERIALS = array(
	'glass'  => 'זכוכית מחוסמת',
	'canvas' => 'קנבס מתוח על עץ (כולל מתיחה)',
);

function lev_default_pricelist() {
	// Shoval's own prices (WhatsApp screenshots, 2026-10-23). Landscape = the portrait sizes turned sideways.
	$p_glass  = array( '20×30' => 199, '30×45' => 235, '40×60' => 320, '50×70' => 375, '60×90' => 550, '70×100' => 670, '80×120' => 890, '100×150' => 1490 );
	$p_canvas = array( '20×30' => 69, '25×35' => 79, '30×45' => 120, '35×50' => 149, '40×60' => 199, '50×70' => 229, '60×90' => 280, '70×100' => 350, '90×120' => 499, '100×150' => 660 );
	$flip     = function ( $list ) {
		$out = array();
		foreach ( $list as $size => $price ) {
			$out[ implode( '×', array_reverse( explode( '×', $size ) ) ) ] = $price;
		}
		return $out;
	};
	return array(
		'portrait'  => array( 'label' => 'אורך', 'glass' => $p_glass, 'canvas' => $p_canvas ),
		'landscape' => array( 'label' => 'רוחב', 'glass' => $flip( $p_glass ), 'canvas' => $flip( $p_canvas ) ),
		'panoramic' => array(
			'label'  => 'פנורמי',
			// panoramic pictures are wide: written wide-first like landscape (Shoval's screenshot lists them narrow-first)
			'glass'  => $flip( array( '30×60' => 310, '40×80' => 365, '50×100' => 540, '60×120' => 680, '70×140' => 980, '80×160' => 1389, '100×200' => 2480 ) ),
			'canvas' => $flip( array( '20×40' => 69, '30×60' => 139, '40×80' => 219, '50×100' => 299, '60×120' => 389, '70×140' => 539, '80×160' => 609, '90×180' => 760, '100×200' => 870 ) ),
		),
	);
}

function lev_settings() {
	$s = wp_parse_args( get_option( 'lev_addons', array() ), array( 'screws' => array( 'זהב', 'כסף', 'שחור' ), 'install' => 150 ) );
	$s['prices'] = get_option( 'lev_pricelist' ) ?: lev_default_pricelist();
	return $s;
}

function lev_format( $product ) {
	$id = is_object( $product ) ? $product->get_id() : (int) $product;
	$f  = get_post_meta( $id, '_lev_format', true );
	return isset( lev_settings()['prices'][ $f ] ) ? $f : '';
}

function lev_min_price( $format ) {
	$p   = lev_settings()['prices'][ $format ];
	$all = array_merge( array_values( (array) $p['glass'] ), array_values( (array) $p['canvas'] ) );
	return $all ? min( $all ) : 0;
}

// size text that reads left-to-right inside Hebrew (so 100×150 never shows as 150×100)
function lev_size( $size ) {
	return "\u{2066}" . $size . "\u{2069}";
}

// keep each picture's shop price at its lowest option, so listings, sorting and "from" prices are right
function lev_sync_price( $product_id ) {
	$f = lev_format( $product_id );
	if ( ! $f ) {
		return;
	}
	$min = (string) lev_min_price( $f );
	update_post_meta( $product_id, '_regular_price', $min );
	update_post_meta( $product_id, '_price', $min );
	wc_delete_product_transients( $product_id );
}

// ---------- shop side ----------

add_filter( 'woocommerce_get_price_html', function ( $html, $product ) {
	$f = lev_format( $product );
	return $f ? '<span class="lev-from">החל מ־</span>' . wc_price( lev_min_price( $f ) ) : $html;
}, 10, 2 );

// in listings, a picture's button opens the picture (sizes are chosen there) instead of adding straight to the cart
add_filter( 'woocommerce_product_add_to_cart_url', function ( $url, $product ) {
	return lev_format( $product ) ? get_permalink( $product->get_id() ) : $url;
}, 10, 2 );
add_filter( 'woocommerce_product_add_to_cart_text', function ( $text, $product ) {
	return lev_format( $product ) ? 'לפרטים ובחירה' : $text; // same words as every other card
}, 10, 2 );
add_filter( 'woocommerce_product_supports', function ( $yes, $feature, $product ) {
	return ( 'ajax_add_to_cart' === $feature && lev_format( $product ) ) ? false : $yes;
}, 10, 3 );

add_action( 'woocommerce_before_add_to_cart_button', function () {
	global $product;
	$f = lev_format( $product );
	if ( ! $f ) {
		return;
	}
	$s   = lev_settings();
	$fmt = $s['prices'][ $f ];
	echo '<div class="lev-pic" data-install="' . esc_attr( $s['install'] ) . '">';
	echo '<div class="lev-row"><span class="lev-k">סוג הדפסה</span><div class="lev-mats">';
	foreach ( LEV_MATERIALS as $key => $label ) {
		if ( empty( $fmt[ $key ] ) ) {
			continue;
		}
		printf( '<label class="lev-mat"><input type="radio" name="lev_mat" value="%s"%s><span>%s</span></label>', esc_attr( $key ), 'glass' === $key ? ' checked' : '', esc_html( $label ) );
	}
	echo '</div></div>';
	foreach ( LEV_MATERIALS as $key => $label ) {
		if ( empty( $fmt[ $key ] ) ) {
			continue;
		}
		printf( '<label class="lev-row lev-sizes" data-mat="%s"><span class="lev-k">מידה <small>(%s, בס״מ)</small></span><select name="lev_size_%s"><option value="">בחירת מידה</option>', esc_attr( $key ), esc_html( $fmt['label'] ), esc_attr( $key ) );
		foreach ( $fmt[ $key ] as $size => $price ) {
			printf( '<option value="%s" data-price="%s">%s</option>', esc_attr( $size ), esc_attr( $price ), esc_html( lev_size( $size ) . ' — ₪' . number_format_i18n( $price ) ) );
		}
		echo '</select></label>';
	}
	echo '<label class="lev-row" data-mat="glass"><span class="lev-k">צבע ברגים</span><select name="lev_screws">';
	foreach ( $s['screws'] as $name ) {
		printf( '<option value="%1$s">%1$s</option>', esc_attr( $name ) );
	}
	echo '</select><small class="lev-note">ברגי תלייה כלולים במחיר</small></label>';
	if ( (float) $s['install'] > 0 ) {
		printf( '<label class="lev-install"><input type="checkbox" name="lev_install" value="1"><span>%s</span></label>', esc_html( 'התקנה על הקיר (+₪' . number_format_i18n( $s['install'] ) . ')' ) );
	}
	echo '<div class="lev-total">סה״כ: <b>—</b></div></div>';
}, 5 );

add_action( 'wp_footer', function () {
	if ( ! is_product() || ! lev_format( get_queried_object_id() ) ) {
		return;
	}
	?>
	<script>
	(function () {
		var box = document.querySelector('.lev-pic'); if (!box) return;
		var form = box.closest('form'), install = parseFloat(box.dataset.install) || 0;
		function mat() { var r = box.querySelector('input[name=lev_mat]:checked'); return r ? r.value : ''; }
		function sync() {
			var m = mat();
			box.querySelectorAll('[data-mat]').forEach(function (el) {
				var on = el.dataset.mat === m;
				el.style.display = on ? '' : 'none';
				el.querySelectorAll('select').forEach(function (s) { s.disabled = !on; });
			});
			box.querySelectorAll('.lev-mat').forEach(function (l) { l.classList.toggle('on', l.querySelector('input').checked); });
			var sel = box.querySelector('.lev-sizes[data-mat="' + m + '"] select'), opt = sel && sel.selectedOptions[0];
			var price = opt && opt.dataset.price ? parseFloat(opt.dataset.price) : 0;
			var inst = box.querySelector('input[name=lev_install]');
			if (price && inst && inst.checked) price += install;
			var q = form.querySelector('input.qty'); price *= Math.max(1, parseInt(q && q.value, 10) || 1); // the total counts the quantity
			box.querySelector('.lev-total b').textContent = price ? '₪' + price.toLocaleString('he-IL') : 'בחרו מידה';
			var btn = form.querySelector('.single_add_to_cart_button'); if (btn) btn.classList.toggle('disabled', !price);
		}
		box.addEventListener('change', sync);
		form.addEventListener('input', function (e) { if (e.target.matches('input.qty')) sync(); });
		form.addEventListener('change', function (e) { if (e.target.matches('input.qty')) sync(); });
		form.addEventListener('submit', function (e) {
			var sel = box.querySelector('.lev-sizes[data-mat="' + mat() + '"] select');
			if (!sel || !sel.value) { e.preventDefault(); sel && sel.focus(); box.classList.add('need'); }
		});
		sync();
	})();
	</script>
	<?php
} );

add_filter( 'woocommerce_add_to_cart_validation', function ( $ok, $product_id ) {
	$f = lev_format( $product_id );
	if ( ! $f ) {
		return $ok;
	}
	$mat  = sanitize_key( wp_unslash( $_POST['lev_mat'] ?? '' ) ); // phpcs:ignore WordPress.Security.NonceVerification
	$size = wc_clean( wp_unslash( $_POST[ 'lev_size_' . $mat ] ?? '' ) );
	if ( ! isset( lev_settings()['prices'][ $f ][ $mat ][ $size ] ) ) {
		wc_add_notice( 'יש לבחור סוג הדפסה ומידה.', 'error' );
		return false;
	}
	return $ok;
}, 10, 2 );

// the choice travels with the cart line; the price is looked up on the server, never taken from the browser
add_filter( 'woocommerce_add_cart_item_data', function ( $data, $product_id ) {
	$f = lev_format( $product_id );
	if ( ! $f ) {
		return $data;
	}
	$s    = lev_settings();
	$mat  = sanitize_key( wp_unslash( $_POST['lev_mat'] ?? '' ) ); // phpcs:ignore WordPress.Security.NonceVerification
	$size = wc_clean( wp_unslash( $_POST[ 'lev_size_' . $mat ] ?? '' ) );
	if ( ! isset( $s['prices'][ $f ][ $mat ][ $size ] ) ) {
		return $data;
	}
	$data['lev'] = array( 'format' => $f, 'mat' => $mat, 'size' => $size );
	if ( 'glass' === $mat && isset( $_POST['lev_screws'] ) && in_array( wp_unslash( $_POST['lev_screws'] ), $s['screws'], true ) ) {
		$data['lev']['screws'] = wc_clean( wp_unslash( $_POST['lev_screws'] ) );
	}
	if ( ! empty( $_POST['lev_install'] ) ) {
		$data['lev']['install'] = 1;
	}
	return $data;
}, 10, 2 );

add_action( 'woocommerce_before_calculate_totals', function ( $cart ) {
	$s = lev_settings();
	foreach ( $cart->get_cart() as $item ) {
		if ( empty( $item['lev'] ) ) {
			continue;
		}
		$l     = $item['lev'];
		$price = (float) ( $s['prices'][ $l['format'] ][ $l['mat'] ][ $l['size'] ] ?? 0 );
		if ( ! empty( $l['install'] ) ) {
			$price += (float) $s['install'];
		}
		if ( $price > 0 ) {
			$item['data']->set_price( $price ); // absolute price: safe however many times totals run
		}
	}
}, 20 );

function lev_rows( $l ) {
	$rows = array(
		'סוג הדפסה' => LEV_MATERIALS[ $l['mat'] ] ?? $l['mat'],
		'מידה'      => lev_size( $l['size'] ) . ' (' . ( lev_settings()['prices'][ $l['format'] ]['label'] ?? '' ) . ')',
	);
	if ( ! empty( $l['screws'] ) ) {
		$rows['צבע ברגים'] = $l['screws'];
	}
	if ( ! empty( $l['install'] ) ) {
		$rows['התקנה'] = 'כן';
	}
	return $rows;
}

add_filter( 'woocommerce_get_item_data', function ( $rows, $item ) {
	if ( ! empty( $item['lev'] ) ) {
		foreach ( lev_rows( $item['lev'] ) as $k => $v ) {
			$rows[] = array( 'key' => $k, 'value' => $v );
		}
	}
	return $rows;
}, 10, 2 );

add_action( 'woocommerce_checkout_create_order_line_item', function ( $line, $key, $item ) {
	if ( ! empty( $item['lev'] ) ) {
		foreach ( lev_rows( $item['lev'] ) as $k => $v ) {
			$line->add_meta_data( $k, $v );
		}
	}
}, 10, 3 );

// ---------- admin: the format on each picture ----------

add_action( 'add_meta_boxes_product', function () {
	add_meta_box( 'lev_format', 'פורמט התמונה', function ( $post ) {
		$cur = get_post_meta( $post->ID, '_lev_format', true );
		wp_nonce_field( 'lev_format', 'lev_format_nonce' );
		echo '<p style="margin-top:0">קובע אילו מידות ומחירים יופיעו ללקוח (מתוך "מחירון תמונות").</p>';
		foreach ( lev_settings()['prices'] as $key => $fmt ) {
			printf( '<label style="display:block;margin:6px 0"><input type="radio" name="lev_format" value="%s"%s> %s</label>', esc_attr( $key ), checked( $cur, $key, false ), esc_html( $fmt['label'] ) );
		}
		printf( '<label style="display:block;margin:6px 0"><input type="radio" name="lev_format" value=""%s> לא תמונה (מוצר רגיל)</label>', checked( $cur, '', false ) );
		echo '<p><a href="' . esc_url( admin_url( 'edit.php?post_type=product&page=lev-prices' ) ) . '">עריכת המחירון ←</a></p>';
	}, 'product', 'side', 'high' );
} );

add_action( 'save_post_product', function ( $id ) {
	if ( ! isset( $_POST['lev_format_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['lev_format_nonce'] ) ), 'lev_format' ) || ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) ) {
		return;
	}
	update_post_meta( $id, '_lev_format', sanitize_key( wp_unslash( $_POST['lev_format'] ?? '' ) ) );
	lev_sync_price( $id );
}, 20 );

// format column in the product list
add_filter( 'manage_edit-product_columns', function ( $cols ) {
	$cols['lev_format'] = 'פורמט';
	return $cols;
} );
add_action( 'manage_product_posts_custom_column', function ( $col, $id ) {
	if ( 'lev_format' === $col ) {
		$f = lev_format( $id );
		echo $f ? esc_html( lev_settings()['prices'][ $f ]['label'] ) : '—';
	}
}, 10, 2 );

// ---------- admin: the price list (מוצרים → מחירון תמונות) ----------

add_action( 'admin_menu', function () {
	add_submenu_page( 'edit.php?post_type=product', 'מחירון תמונות', 'מחירון תמונות', 'manage_woocommerce', 'lev-prices', 'lev_prices_screen' );
} );

function lev_prices_screen() {
	if ( isset( $_POST['lev_prices_nonce'] ) && wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['lev_prices_nonce'] ) ), 'lev_prices' ) ) {
		$old  = lev_settings()['prices'];
		$list = array();
		foreach ( $old as $fk => $fmt ) {
			$list[ $fk ] = array( 'label' => sanitize_text_field( wp_unslash( $_POST['label'][ $fk ] ?? $fmt['label'] ) ) );
			foreach ( array_keys( LEV_MATERIALS ) as $mk ) {
				$rows = array();
				foreach ( (array) ( $_POST['size'][ $fk ][ $mk ] ?? array() ) as $i => $size ) {
					$size  = str_replace( array( 'x', 'X', '*' ), '×', trim( sanitize_text_field( wp_unslash( $size ) ) ) );
					$price = (float) ( $_POST['price'][ $fk ][ $mk ][ $i ] ?? 0 );
					if ( '' !== $size && $price > 0 ) {
						$rows[ $size ] = $price;
					}
				}
				$list[ $fk ][ $mk ] = $rows;
			}
		}
		update_option( 'lev_pricelist', $list );
		$screws = array_values( array_filter( array_map( 'trim', explode( ',', sanitize_text_field( wp_unslash( $_POST['screws'] ?? '' ) ) ) ), 'strlen' ) );
		update_option( 'lev_addons', array( 'screws' => $screws, 'install' => (float) ( $_POST['install'] ?? 0 ) ) );
		foreach ( get_posts( array( 'post_type' => 'product', 'numberposts' => -1, 'fields' => 'ids', 'meta_key' => '_lev_format' ) ) as $pid ) {
			lev_sync_price( $pid );
		}
		echo '<div class="notice notice-success"><p>המחירון נשמר ועודכן בכל התמונות.</p></div>';
	}
	$s = lev_settings();
	echo '<div class="wrap lev-prices"><h1>מחירון תמונות</h1>';
	echo '<p>לכל תמונה בוחרים פורמט (בעמוד המוצר, בתיבה "פורמט התמונה"). המחירים כאן חלים על כל התמונות באותו פורמט. שורה ריקה בסוף כל טבלה = מידה חדשה; מחיקת המידה = הסרה.</p>';
	echo '<style>.lev-prices .fmt{display:flex;gap:28px;flex-wrap:wrap;margin:10px 0 28px}.lev-prices table{width:300px}.lev-prices input.size{width:110px;direction:ltr;text-align:center}.lev-prices input.price{width:90px}</style>';
	echo '<form method="post">';
	wp_nonce_field( 'lev_prices', 'lev_prices_nonce' );
	foreach ( $s['prices'] as $fk => $fmt ) {
		printf( '<h2>פורמט: <input name="label[%s]" value="%s" style="font-size:1em;width:140px"></h2><div class="fmt">', esc_attr( $fk ), esc_attr( $fmt['label'] ) );
		foreach ( LEV_MATERIALS as $mk => $mlabel ) {
			printf( '<table class="widefat striped"><thead><tr><th colspan="2">%s</th></tr><tr><th>מידה (ס״מ)</th><th>מחיר ₪</th></tr></thead><tbody>', esc_html( $mlabel ) );
			foreach ( (array) $fmt[ $mk ] + array( '' => '' ) as $size => $price ) {
				printf( '<tr><td><input class="size" name="size[%1$s][%2$s][]" value="%3$s" placeholder="50×70"></td><td><input class="price" type="number" min="0" step="1" name="price[%1$s][%2$s][]" value="%4$s"></td></tr>', esc_attr( $fk ), esc_attr( $mk ), esc_attr( $size ), esc_attr( $price ) );
			}
			echo '</tbody></table>';
		}
		echo '</div>';
	}
	printf( '<h2>צבעי ברגים (לזכוכית)</h2><input name="screws" class="regular-text" value="%s"><p class="description">מופרדים בפסיק.</p>', esc_attr( implode( ', ', $s['screws'] ) ) );
	printf( '<h2>התקנה</h2><input name="install" type="number" step="1" min="0" value="%s"> ₪ <span class="description">0 = בלי אפשרות התקנה</span>', esc_attr( $s['install'] ) );
	submit_button( 'שמירת המחירון' );
	echo '</form></div>';
}

// ---------- "see it on your wall": the customer's own room photo (or ours), with the picture placed on it ----------
// Everything happens in the customer's browser: no upload to the server, no AI, no cost.
add_action( 'woocommerce_after_add_to_cart_form', function () {
	global $product;
	if ( ! lev_format( $product ) ) {
		return;
	}
	$img  = get_the_post_thumbnail_url( $product->get_id(), 'large' ) ?: wc_placeholder_img_src( 'large' );
	$room = get_theme_file_uri( 'assets/img/hero.jpg' );
	echo '<button type="button" class="lev-wall-open">איך זה ייראה אצלי על הקיר?</button>';
	printf(
		'<div class="lev-wall" hidden data-img="%s" data-room="%s"><div class="lev-wall-box"><button type="button" class="lev-wall-x" aria-label="סגירה">×</button><h3>%s על הקיר שלכם</h3><p class="lev-wall-help">מעלים תמונה של הקיר, גוררים את התמונה למקום ומגדילים או מקטינים. התמונה לא נשלחת לשום מקום.</p><div class="lev-wall-stage"><img class="lev-wall-bg" alt=""><div class="lev-wall-art"><img alt=""><span class="lev-wall-grip"></span></div></div><div class="lev-wall-bar"><label class="lev-wall-up">העלאת תמונה של הקיר<input type="file" accept="image/*"></label><label class="lev-wall-size">גודל <input type="range" min="8" max="70" value="26"></label><span class="lev-wall-dim"></span></div></div></div>',
		esc_url( $img ),
		esc_url( $room ),
		esc_html( $product->get_name() )
	);
} );

add_action( 'wp_footer', function () {
	if ( ! is_product() || ! lev_format( get_queried_object_id() ) ) {
		return;
	}
	?>
	<script>
	(function () {
		var wrap = document.querySelector('.lev-wall'), open = document.querySelector('.lev-wall-open'); if (!wrap || !open) return;
		var stage = wrap.querySelector('.lev-wall-stage'), bg = wrap.querySelector('.lev-wall-bg'), art = wrap.querySelector('.lev-wall-art');
		var range = wrap.querySelector('input[type=range]'), dim = wrap.querySelector('.lev-wall-dim');
		art.querySelector('img').src = wrap.dataset.img; bg.src = wrap.dataset.room;
		var pos = { x: 50, y: 32 };
		// the picture's proportions follow the size chosen on the page (e.g. 50×70 → portrait), default 2:3
		function ratio() {
			var box = document.querySelector('.lev-pic'), m = box && box.querySelector('input[name=lev_mat]:checked');
			var sel = m && box.querySelector('.lev-sizes[data-mat="' + m.value + '"] select');
			var v = sel && sel.value ? sel.value : '';
			var p = v.split('×').map(parseFloat);
			dim.textContent = v ? 'מידה: ' + v + ' ס״מ' : 'בחרו מידה בעמוד כדי לראות את הפרופורציה המדויקת';
			return p.length === 2 && p[0] && p[1] ? p[1] / p[0] : 1.5; // height / width, sizes are written width×height
		}
		function draw() {
			var w = parseFloat(range.value);
			art.style.width = w + '%'; art.style.aspectRatio = '1 / ' + ratio();
			art.style.left = pos.x + '%'; art.style.top = pos.y + '%';
		}
		// on the sample room the picture starts at its real size: the room photo is about 350 cm of wall across
		var ROOM_CM = 350;
		open.addEventListener('click', function () {
			wrap.hidden = false; document.body.style.overflow = 'hidden'; ratio();
			var cm = parseFloat((dim.textContent.match(/(\d+)×/) || [])[1]);
			if (cm && bg.src.indexOf('blob:') !== 0) range.value = Math.max(8, Math.min(70, cm / ROOM_CM * 100));
			draw();
		});
		wrap.querySelector('.lev-wall-x').addEventListener('click', function () { wrap.hidden = true; document.body.style.overflow = ''; });
		wrap.addEventListener('click', function (e) { if (e.target === wrap) wrap.querySelector('.lev-wall-x').click(); });
		range.addEventListener('input', draw);
		wrap.querySelector('input[type=file]').addEventListener('change', function () {
			var f = this.files && this.files[0]; if (f) bg.src = URL.createObjectURL(f);
		});
		// drag to move (mouse and touch)
		var drag = null;
		art.addEventListener('pointerdown', function (e) {
			var r = stage.getBoundingClientRect();
			drag = { sx: e.clientX, sy: e.clientY, x: pos.x, y: pos.y, w: r.width, h: r.height, resize: e.target.classList.contains('lev-wall-grip'), size: parseFloat(range.value) };
			art.setPointerCapture(e.pointerId); e.preventDefault();
		});
		art.addEventListener('pointermove', function (e) {
			if (!drag) return;
			if (drag.resize) { range.value = Math.max(8, Math.min(70, drag.size + (drag.sx - e.clientX) / drag.w * 100 * 2)); }
			else { pos.x = Math.max(0, Math.min(100, drag.x + (e.clientX - drag.sx) / drag.w * 100)); pos.y = Math.max(0, Math.min(100, drag.y + (e.clientY - drag.sy) / drag.h * 100)); }
			draw();
		});
		art.addEventListener('pointerup', function () { drag = null; });
		document.addEventListener('change', function (e) { if (e.target.closest && e.target.closest('.lev-pic')) draw(); });
	})();
	</script>
	<?php
} );
