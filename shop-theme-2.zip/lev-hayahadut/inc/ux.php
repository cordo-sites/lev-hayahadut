<?php
// לב היהדות — shopping comfort (Amir's review, 2026-10-25). Copied into the theme as inc/ux.php by build-wp-theme.cjs.
// 1. account icon opens a small login panel on the page instead of a slow full page
// 2. colour choices as colour boxes instead of a dropdown
// 3. product details tab with real content (replaces the near-empty "additional information" table)
// 4. clearer card buttons
// 5. WhatsApp: a floating button and a contact-page button, shown once the number is set (Settings → General)

// ---------- 1. login panel ----------
add_action( 'wp_footer', function () {
	if ( is_user_logged_in() || ! function_exists( 'wc_get_page_permalink' ) ) {
		return;
	}
	$account = wc_get_page_permalink( 'myaccount' );
	?>
	<div class="lev-login" hidden role="dialog" aria-label="התחברות">
		<button type="button" class="lev-login-x" aria-label="סגירה">×</button>
		<b class="lev-login-title">התחברות</b>
		<form method="post" action="<?php echo esc_url( $account ); ?>">
			<label><span>אימייל</span><input type="text" name="username" autocomplete="username" required></label>
			<label><span>סיסמה</span><input type="password" name="password" autocomplete="current-password" required></label>
			<?php wp_nonce_field( 'woocommerce-login', 'woocommerce-login-nonce' ); ?>
			<input type="hidden" name="rememberme" value="forever">
			<button type="submit" class="wp-element-button" name="login" value="התחברות">התחברות</button>
		</form>
		<div class="lev-login-links">
			<a href="<?php echo esc_url( wp_lostpassword_url() ); ?>">שכחתי סיסמה</a>
			<a href="<?php echo esc_url( $account ); ?>">לקוח חדש? הרשמה</a>
		</div>
	</div>
	<script>
	(function () {
		var panel = document.querySelector('.lev-login'); if (!panel) return;
		document.addEventListener('click', function (e) {
			var link = e.target.closest('.wc-block-customer-account__link, .wc-block-customer-account a');
			if (link) { e.preventDefault(); panel.hidden = !panel.hidden; if (!panel.hidden) panel.querySelector('input').focus(); return; }
			if (!panel.hidden && !e.target.closest('.lev-login')) panel.hidden = true;
		});
		panel.querySelector('.lev-login-x').addEventListener('click', function () { panel.hidden = true; });
		document.addEventListener('keydown', function (e) { if (e.key === 'Escape') panel.hidden = true; });
	})();
	</script>
	<?php
} );

// ---------- 2. every option as buttons (Amir, 2026-10-25: "some are scroll, some are click — make it one way") ----------
// Each dropdown on a product page (size, colour, finish, contents, picture size, screw colour) becomes a row of buttons.
// The dropdown stays hidden underneath, so WooCommerce and the picture price list keep working unchanged.
add_action( 'wp_footer', function () {
	if ( ! is_product() ) {
		return;
	}
	?>
	<script>
	(function () {
		var COLORS = { 'שחור': '#141210', 'זהב': 'linear-gradient(135deg,#a8843a,#eed9a0 50%,#b38f45)', 'לבן': '#fffdf9', 'כסף': 'linear-gradient(135deg,#8d8d8d,#eaeaea 50%,#9e9e9e)', 'שקוף': 'repeating-conic-gradient(#e7e2d8 0 25%,#fff 0 50%) 0 0/10px 10px', 'זהב כהה': '#9b7b35', 'זהב בהיר': '#e8d395' };
		function chips(sel, isColor) {
			if (sel.dataset.chips) return; sel.dataset.chips = '1';
			var box = document.createElement('div'); box.className = 'lev-chips';
			[].slice.call(sel.options).forEach(function (o) {
				if (!o.value) return;
				var b = document.createElement('button'); b.type = 'button'; b.className = 'lev-chip'; b.dataset.v = o.value;
				var label = o.textContent.replace(/\s+—\s+/, '  ·  ');
				b.innerHTML = (isColor ? '<i style="background:' + (COLORS[o.value] || COLORS[o.textContent] || '#ccc') + '"></i>' : '') + '<span>' + label + '</span>';
				b.addEventListener('click', function () { sel.value = o.value; sel.dispatchEvent(new Event('change', { bubbles: true })); if (window.jQuery) jQuery(sel).trigger('change'); mark(); });
				box.appendChild(b);
			});
			// a long list (picture sizes) folds behind one button showing the choice (Shoval, 2026-10-26: "sizes on a button that opens")
			var pick = null;
			if (box.children.length > 4) {
				pick = document.createElement('button'); pick.type = 'button'; pick.className = 'lev-pick'; pick.setAttribute('aria-expanded', 'false');
				box.hidden = true;
				pick.addEventListener('click', function () { box.hidden = !box.hidden; pick.setAttribute('aria-expanded', String(!box.hidden)); });
				box.addEventListener('click', function (e) { if (e.target.closest('.lev-chip')) { box.hidden = true; pick.setAttribute('aria-expanded', 'false'); } });
			}
			function mark() {
				box.querySelectorAll('.lev-chip').forEach(function (b) { b.classList.toggle('on', b.dataset.v === sel.value); });
				if (pick) { var on = box.querySelector('.lev-chip.on'); pick.innerHTML = '<span>' + (on ? on.textContent : 'בחירת מידה') + '</span><b aria-hidden="true">▾</b>'; }
			}
			sel.style.display = 'none'; if (pick) sel.parentNode.insertBefore(pick, sel); sel.parentNode.insertBefore(box, sel); sel.addEventListener('change', mark);
			if (window.jQuery) jQuery(sel).on('change', mark);
			mark();
		}
		document.querySelectorAll('table.variations tr').forEach(function (row) {
			var label = row.querySelector('label'), sel = row.querySelector('select');
			if (sel) chips(sel, label && /צבע/.test(label.textContent));
		});
		document.querySelectorAll('.lev-pic select').forEach(function (sel) {
			// a picture opens with a size already chosen (50×70, the usual living-room size), so a price shows at once
			if (!sel.value && /^lev_size_/.test(sel.name)) {
				var o = [].find.call(sel.options, function (x) { return /50\D+70/.test(x.textContent); }) || sel.options[Math.ceil(sel.options.length / 2)];
				if (o) { sel.value = o.value; sel.dispatchEvent(new Event('change', { bubbles: true })); }
			}
			chips(sel, sel.name === 'lev_screws');
		});
		var reset = document.querySelector('.reset_variations'); if (reset) reset.style.display = 'none';
	})();
	</script>
	<?php
}, 30 );

// ---------- 3. product details ----------
add_filter( 'woocommerce_product_tabs', function ( $tabs ) {
	unset( $tabs['additional_information'] );
	$tabs['lev_details'] = array( 'title' => 'פרטים', 'priority' => 5, 'callback' => 'lev_details_tab' );
	if ( isset( $tabs['description'] ) ) {
		$tabs['description']['priority'] = 4;
	}
	return $tabs;
}, 99 );

function lev_details_tab() {
	global $product;
	$is_pic = function_exists( 'lev_format' ) && lev_format( $product );
	$points = $is_pic
		? array(
			'הדפסה באיכות גבוהה, בצבעים עמידים',
			'זכוכית מחוסמת — נתלית עם ברגים מעוצבים שכלולים במחיר',
			'קנבס — מתוח על מסגרת עץ, מגיע מוכן לתלייה',
			'אפשר להוסיף התקנה על הקיר',
			'גדלים לפי בקשה ושם או הקדשה — בתיאום',
		)
		: array(
			'גימור מוקפד, נבחר בקפידה',
			'אריזת מתנה מהודרת לפי בקשה',
			'התאמה אישית — שם או הקדשה, בתיאום',
		);
	echo '<div class="lev-details"><ul>';
	foreach ( $points as $p ) {
		echo '<li>' . esc_html( $p ) . '</li>';
	}
	echo '</ul><div class="lev-details-side">';
	echo '<p><b>משלוח</b> עד הבית לכל הארץ.</p>';
	echo '<p><b>החזרות</b> עד 14 יום מקבלת המוצר, באריזה המקורית וללא שימוש. מוצר שהגיע פגום מוחלף ללא עלות.</p>'; // said here in short (Amir 2026-10-28), not only behind a link
	echo '<p><b>שאלה על הפריט?</b> <a href="' . esc_url( home_url( '/contact/' ) ) . '">דברו איתנו</a>.</p>';
	echo '</div></div>';
}

// ---------- 4. card buttons ----------
add_filter( 'woocommerce_product_add_to_cart_text', function ( $text, $product ) {
	return 'לפרטים ובחירה'; // every card says the same thing (pictures said "בחירת מידה")
}, 20, 2 );

// ---------- 5. WhatsApp ----------
add_action( 'admin_init', function () {
	register_setting( 'general', 'lev_whatsapp', array( 'type' => 'string', 'sanitize_callback' => function ( $v ) { return preg_replace( '/\D/', '', (string) $v ); } ) );
	add_settings_field( 'lev_whatsapp', 'מספר וואטסאפ לחנות', function () {
		printf( '<input name="lev_whatsapp" type="tel" class="regular-text" dir="ltr" value="%s" placeholder="0501234567"><p class="description">מופיע ככפתור וואטסאפ באתר ובעמוד צור קשר. ריק = בלי כפתור.</p>', esc_attr( get_option( 'lev_whatsapp', '' ) ) );
	}, 'general' );
} );

function lev_wa_link( $text = '' ) {
	$n = get_option( 'lev_whatsapp', '' );
	if ( ! $n ) {
		return '';
	}
	if ( 0 === strpos( $n, '0' ) ) {
		$n = '972' . substr( $n, 1 ); // Israeli number → international format for wa.me
	}
	return 'https://wa.me/' . $n . ( $text ? '?text=' . rawurlencode( $text ) : '' );
}

add_action( 'wp_footer', function () {
	$link = lev_wa_link( 'שלום, יש לי שאלה על המוצרים באתר' );
	if ( ! $link ) {
		return;
	}
	printf( '<a class="lev-wa" href="%s" target="_blank" rel="noopener" aria-label="וואטסאפ"><svg viewBox="0 0 32 32" aria-hidden="true"><path d="M16 3a13 13 0 0 0-11.2 19.6L3 29l6.6-1.7A13 13 0 1 0 16 3zm0 23.6c-2 0-4-.6-5.7-1.6l-.4-.2-3.9 1 1-3.8-.3-.4A10.6 10.6 0 1 1 16 26.6zm5.8-7.9c-.3-.2-1.9-1-2.2-1s-.5-.2-.7.2-.8 1-1 1.2-.4.2-.7 0a8.7 8.7 0 0 1-4.3-3.8c-.3-.6.3-.5.9-1.6.1-.2 0-.4 0-.5l-1-2.4c-.3-.6-.5-.5-.7-.5h-.6c-.2 0-.6.1-.9.4s-1.2 1.1-1.2 2.8 1.2 3.3 1.4 3.5 2.4 3.6 5.8 5c2.1.9 3 1 4 .8.7-.1 1.9-.8 2.2-1.5s.3-1.4.2-1.5-.3-.2-.6-.4z"/></svg></a>', esc_url( $link ) );
} );

add_shortcode( 'lev_wa', function () {
	$link = lev_wa_link( 'שלום, אשמח לפרטים' );
	return $link ? '<p><a class="lev-wa-btn" href="' . esc_url( $link ) . '" target="_blank" rel="noopener">שליחת הודעה בוואטסאפ</a></p>' : '';
} );

// ---------- 6. Hebrew for the last English lines (QA 2026-10-26) ----------
add_filter( 'gettext', function ( $t, $text ) {
	if ( 0 === strpos( $text, 'Search results for: ' ) ) {
		return 'תוצאות חיפוש: %s';
	}
	return $t;
}, 20, 2 );
add_filter( 'woocommerce_get_privacy_policy_text', function () {
	return 'הפרטים שלך ישמשו לטיפול בהזמנה, לניהול החשבון ולמטרות המתוארות ב[privacy_policy].';
} );

// ---------- 7. prices read the same everywhere (design review 2026-10-26) ----------
// whole shekels (no .00), and a product with sizes shows "החל מ־₪119" like the pictures do, instead of a range
add_filter( 'wc_get_price_decimals', function () { return 0; } );
add_filter( 'woocommerce_variable_price_html', function ( $html, $product ) {
	$min = $product->get_variation_price( 'min', true );
	return $min ? '<span class="lev-from">החל מ־</span>' . wc_price( $min ) : $html;
}, 10, 2 );

// ---------- 8. version 2 extras (design review 2026-10-26) ----------
// WooCommerce leaves its cart icon out on the cart and checkout pages; put a plain link with the count back
add_filter( 'render_block_woocommerce/mini-cart', function ( $html ) {
	if ( ( is_cart() || is_checkout() ) && function_exists( 'WC' ) && WC()->cart ) {
		$n = WC()->cart->get_cart_contents_count();
		return '<a class="lev-cart-link" href="' . esc_url( wc_get_cart_url() ) . '" aria-label="סל הקניות"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" aria-hidden="true"><path d="M3 4h2l2.4 11h11L21 7H6.2"/><circle cx="9" cy="19.5" r="1.3"/><circle cx="17" cy="19.5" r="1.3"/></svg>' . ( $n ? '<b>' . (int) $n . '</b>' : '' ) . '</a>';
	}
	return $html;
} );
// no coupon box until the shop has coupons
add_filter( 'woocommerce_coupons_enabled', '__return_false' );
// "5 עיצובים" alone under the price read as unfinished
add_filter( 'woocommerce_short_description', function ( $d ) {
	return preg_replace( '/(\d+\s+עיצובים)(?!\s+לבחירה)/u', '$1 לבחירה', $d );
} );
add_filter( 'get_the_excerpt', function ( $d ) { // the product page shows the short text through the excerpt block
	return is_singular( 'product' ) ? preg_replace( '/(\d+\s+עיצובים)(?!\s+לבחירה)/u', '$1 לבחירה', $d ) : $d;
}, 20 );

// "עגלת הקניות" (WooCommerce's word in the cart drawer and the empty cart) → "סל הקניות", as everywhere else on the site
add_filter( 'gettext', function ( $t ) { return str_replace( 'עגלת הקניות', 'סל הקניות', $t ); }, 30 );
add_filter( 'load_script_translations', function ( $json ) { return is_string( $json ) ? str_replace( 'עגלת הקניות', 'סל הקניות', $json ) : $json; } );
add_filter( 'render_block_woocommerce/empty-cart-block', function ( $html ) { return str_replace( array( 'עגלת הקניות שלך ריקה כעת!', 'סל הקניות שלך ריקה כעת!' ), 'סל הקניות ריק', $html ); } );

// ---------- 9. objects: the "סה״כ" line counts the quantity too (₪249 × 4 = ₪996) ----------
add_action( 'wp_footer', function () {
	if ( ! is_product() ) {
		return;
	}
	?>
	<script>
	(function () {
		var form = document.querySelector('form.variations_form'); if (!form) return;
		var line = document.createElement('div'); line.className = 'lev-total lev-qty-total'; line.hidden = true;
		function sync() {
			var amt = form.querySelector('.woocommerce-variation-price .woocommerce-Price-amount'), q = form.querySelector('input.qty');
			var unit = amt ? parseFloat(amt.textContent.replace(/[^\d.]/g, '')) : 0, n = Math.max(1, parseInt(q && q.value, 10) || 1);
			line.hidden = !unit; line.innerHTML = 'סה״כ: <b>₪' + (unit * n).toLocaleString('he-IL') + '</b>';
			var v = form.querySelector('.single_variation'); if (v && line.parentNode !== v) v.appendChild(line);
		}
		form.addEventListener('input', sync); form.addEventListener('change', sync); form.addEventListener('click', function () { setTimeout(sync, 50); });
		if (window.jQuery) jQuery(form).on('found_variation show_variation', function () { setTimeout(sync, 0); });
		setTimeout(sync, 300);
	})();
	</script>
	<?php
}, 40 );
